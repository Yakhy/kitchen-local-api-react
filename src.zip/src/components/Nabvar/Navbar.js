import React from 'react';
import './Navbar.css'

export default function Navbar() {
  return <div className='navbar'> 
<nav>
  <a href="/" className='brand'>
    <h1>Yakhyobek's Kitchen</h1>
  </a>
  <a href="/create" >
    <h1>Create reciepe </h1>
  </a>
</nav>

  </div>;
}
