import './Search.css'

export default function search() {
  return <div></div>;
}
